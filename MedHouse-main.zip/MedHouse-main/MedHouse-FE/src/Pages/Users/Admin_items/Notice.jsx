
function Notice(){
    return<h1>Notice</h1>
}
export default Notice;