
function Requests(){
    return<h1>Requests</h1>
}
export default Requests;